﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;


public class Test1 : MonoBehaviour {

    float[,] randomValues;
    int num = 32;
	// Use this for initialization
	void Start () {
        randomValues = new float[num, num];
        for(int i = 0; i < num; i++) {
            for(int j = 0; j < num; j++) {
                randomValues[i,j]= Random.Range(0.5f,0.8f);
                print(randomValues[i, j]);
            }
        }

        var settings = new TerrainChunckSetting(num, num, 128, 20);
        TerrainChunck terrain = new TerrainChunck(settings,randomValues, 0, 0);
        terrain.CreateTerrain();

    }


}
